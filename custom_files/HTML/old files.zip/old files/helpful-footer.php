<div class="new-footer">
    <h2 style="color:#002E5D">Helpful Links</h2>
    <p style="color:#666"><a href="https://www.et.byu.edu/">Ira A. Fulton College of Engineering</a></p>
    <p style="color:#666"><a href="http://my.byu.edu">myBYU</a></p>
    <p style="color:#666"><a href="https://learningsuite.byu.edu">Learning Suite</a></p>
    <p style="color:#666"><a href="https://calendar.byu.edu/">BYU Calendar</a></p>

</div>
