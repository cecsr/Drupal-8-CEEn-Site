<div class="new-footer">
    <h2 style="color:#002E5D">Contact</h2>
    <p style="color:#666"><a href="tel:+18014222811">(801) 422-2811</a></p>
    <p style="color:#666"><a href="mailto:example@byu.edu">example@byu.edu</a></p>
    <p style="color:#666"><a href="https://goo.gl/maps/A8EBcBVXtgB2" target="_blank">368 Clyde Building <br>Brigham Young University<br>Provo, UT 84604</a></p>
</div>
