<div class="new-footer">
    <h2 style="color:#002E5D">Related Services</h2>
    <p style="color:#666"><a href="http://byui.edu/">BYU-Idaho</a></p>
    <p style="color:#666"><a href="http://byuh.edu/">BYU-Hawaii</a></p>
    <p style="color:#666"><a href="http://ldsbc.edu/">LDS Business College</a></p>
    <p style="color:#666"><a href="http://mormon.org/">LDS Church</a></p>

</div>
